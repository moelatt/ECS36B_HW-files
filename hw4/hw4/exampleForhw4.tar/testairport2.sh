#!/bin/bash
./airport CYQB
