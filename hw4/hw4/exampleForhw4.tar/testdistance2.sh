#!/bin/bash
./distance 24MD 21JN
